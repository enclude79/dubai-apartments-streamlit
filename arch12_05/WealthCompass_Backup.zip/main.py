import asyncio
import logging
import schedule
import time
from datetime import datetime
from openai import OpenAI
from telegram import Bot
from config import (
    TELEGRAM_BOT_TOKEN,
    TELEGRAM_CHANNEL_ID,
    OPENROUTER_API_KEY,
    PROMPTS,
    PUBLISH_TIME
)

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ContentGenerator:
    def __init__(self):
        self.bot = Bot(token=TELEGRAM_BOT_TOKEN)
        self.client = OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=OPENROUTER_API_KEY
        )
        self.channel_id = TELEGRAM_CHANNEL_ID

    async def get_gpt_response(self, prompt: str) -> str:
        """Получение ответа от GPT API"""
        try:
            response = self.client.chat.completions.create(
                extra_headers={
                    "HTTP-Referer": "https://wealthcompas.com",
                    "X-Title": "WealthCompas News Bot",
                },
                model="deepseek/deepseek-chat-v3-0324:free",
                messages=[
                    {"role": "system", "content": "Ты - эксперт по рынку недвижимости в Дубае. Твоя задача - предоставлять актуальную аналитику и инсайты о рынке недвижимости."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=2000
            )
            
            logger.info("Successfully received response from API")
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"Error getting GPT response: {e}")
            return "Произошла ошибка при генерации контента."

    async def publish_to_telegram(self, content: str):
        """Публикация контента в Telegram канал"""
        try:
            # Добавляем заголовок с текущей датой
            current_date = datetime.now().strftime('%d.%m.%Y')
            formatted_content = f"📅 *Аналитика рынка недвижимости от {current_date}*\n\n{content}"
            
            logger.info(f"Attempting to send message to channel {self.channel_id}")
            await self.bot.send_message(
                chat_id=self.channel_id,
                text=formatted_content,
                parse_mode='Markdown'
            )
            logger.info("Content published successfully")
        except Exception as e:
            logger.error(f"Error publishing to Telegram: {e}")
            logger.error(f"Content that failed to send: {content}")

    async def generate_and_publish(self):
        """Основная функция для генерации и публикации контента"""
        current_day = datetime.now().strftime('%A').lower()
        prompt = PROMPTS.get(current_day, "Default prompt")
        logger.info(f"Using prompt for {current_day}")
        
        content = await self.get_gpt_response(prompt)
        await self.publish_to_telegram(content)

async def test_run():
    """Функция для тестового запуска"""
    generator = ContentGenerator()
    await generator.generate_and_publish()

def schedule_task():
    """Планирование задачи"""
    generator = ContentGenerator()
    asyncio.run(generator.generate_and_publish())

def main():
    """Основная функция"""
    logger.info("Starting the bot...")
    
    # Сначала выполним тестовый запуск
    asyncio.run(test_run())
    
    # Затем настроим регулярное выполнение
    schedule.every().day.at(PUBLISH_TIME).do(schedule_task)
    
    while True:
        schedule.run_pending()
        time.sleep(60)

if __name__ == "__main__":
    main() 